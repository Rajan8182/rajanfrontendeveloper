import React from 'react'

const Login = () => {
  return (
    <div className='text-center p-32 bg-slate-300 mt-32'>
      <h1>This is Login Page</h1>
    </div>
  )
}

export default Login

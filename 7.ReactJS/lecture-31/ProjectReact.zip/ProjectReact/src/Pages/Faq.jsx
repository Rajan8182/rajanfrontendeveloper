import React from 'react'

const Faq = () => {
  return (
    <div>
      <h1 className='flex justify-center items-center p-11 bg-green-600 '>This is Faq page</h1>
    </div>
  )
}

export default Faq

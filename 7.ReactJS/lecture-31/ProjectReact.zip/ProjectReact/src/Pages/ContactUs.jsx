import React from 'react'

const ContactUs = () => {
  return (
    <div>
      <h1 className='flex justify-center items-center p-11 bg-green-600 '>This is Contact US page</h1>
    </div>
  )
}

export default ContactUs

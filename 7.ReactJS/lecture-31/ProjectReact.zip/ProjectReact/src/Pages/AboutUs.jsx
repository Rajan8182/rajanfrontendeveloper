import React from 'react'

const AboutUs = () => {
  return (
    <div>
      <h1 className='flex justify-center items-center p-11 bg-green-600 '>This is About Us page</h1>
    </div>
  )
}

export default AboutUs

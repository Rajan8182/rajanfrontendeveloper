import React from 'react'

const Wishlist = () => {
  return (
    <div>
      <h1 className='flex justify-center items-center p-11 bg-green-600 '>This is Wishlist page</h1>
    </div>
  )
}

export default Wishlist

import React from 'react'

const OurMenus = () => {
  return (
    <div>
      <h1 className='flex justify-center items-center p-11 bg-green-600 '>This is Our MEnus page</h1>
    </div>
  )
}

export default OurMenus

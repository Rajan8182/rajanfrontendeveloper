import { WISHLIST_ADD , WISHLIST_REMOVE , WISHLIST_EMPTY } from "./Constant";

const WishlistReducer = (state = [] , action) => {
    switch(action.type){
        case WISHLIST_ADD: return[...state , action.payload]
        case WISHLIST_REMOVE:
        case WISHLIST_EMPTY:
        default:return state
    }
}

export default WishlistReducer